package Java0508;

public class ex01 {
	
	public static void main(String[] args) {
		
		
	}
}
