/*
	
	Date : 2020.05.08
	Author : HyeongRok
	Description : Java 기본설정
	Version : 1.0

*/

package Java0508;

public class ex01_2 {
	public static void main(String[] args) {
		System.out.println("들여쓰기 연습");
		System.out.println("[ctrl] + [shift] + [F]");
		

	}

}
