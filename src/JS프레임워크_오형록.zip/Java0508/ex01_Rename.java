/*
	
	Date : 2020.05.08
	Author : HyeongRok
	Description : Java 기본설정
	Version : 1.0

*/

package Java0508;

public class ex01_Rename {

	public static void main(String[] args) {
		
		// 주석달기
		// 1. 한줄 주석처리
		/* 2. 범위 주석처리 */
		
		// ; =>> 문장의 마침표 역할
		System.out.println("Hi");
		System.out.println("Hi");
		
		// sysout 입력후 [ctrl] + [space]
		System.out.println();
		System.out.println("sysout 입력 후 [ctrl] + [space]");
		
		// 실행(Run) =>> [ctrl] + [F11]
		
		// 저장(save) =>> [crtl] + [s]
		// 모두저장(save all) =>> [crtl] + [shift] + [s]
		// 글씨 크기조정 =>> [crtl] + [-] , [+]
		
		/* 
		 
		 클래스 이름 바꾸기
		 '클래스명 ' 오른쪽 마우스 클릭 => Refactor => Rename
		 
		 *프로젝트, 패키지 동일
		
		 */
	}

}
