/*
	
	Date : 2020.05.08
	Author : HyeongRok
	Description : 변수를 사용해서 자기소개서 만들기
	Version : 1.0

*/

package Java0508;

public class ex02_day01 {

	public static void main(String[] args) {
		
		String name;
		name = "오형록";
		String birth;
		birth = "95.04.22";
		int age;
		age = 26;
		String adr;
		adr = "용현동 매소홀로 59번지";
		String phone;
		phone = "010-4180-5446";
		String email;
		email = "ohr5446@naver.com";
		String hobby;
		hobby = "게임";
		String speciality;
		speciality = "실용음악";
		char blood;
		blood = 'A';
		
		String member1;
		member1 = "이재홍";
		String member2;
		member2 = "유현서";
		String member3;
		member3 = "서재언";
		String member4;
		member4 = "서민재";
		
		System.out.println("제 이름은 " + name + " 입니다.");
		System.out.println("저의 생일은 " + birth + " 입니다.");
		System.out.println("저의 나이는 " + age + " 입니다.");
		System.out.println("저의 주소는" + adr + " 입니다.");
		System.out.println("저의 전화번호는 " + phone + " 입니다.");
		System.out.println("저의 email주소는 " + email + " 입니다.");
		System.out.println("저의 취미는" + hobby + " 입니다.");
		System.out.println("저의 전공은" + speciality + " 입니다.");
		System.out.println("저의 팀원1은 " + member1 + " 입니다.");
		System.out.println("저의 팀원2는 " + member2 + " 입니다.");
		System.out.println("저의 팀원3은 " + member3 + " 입니다.");
		System.out.println("저의 팀원4는" + member4 + " 입니다.");
		

	}

}
